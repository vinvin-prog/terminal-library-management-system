'''
AMIEL VINCENT V. DE CASTRO
Y6L
'''

from cryptography.fernet import Fernet

def key_fernet():
	file_key = open('key.key','rb')
	key = file_key.read()
	return Fernet(key)

def decrypt_file(file):
	f = key_fernet()

	file_books = open(file,'rb')
	encrypted = file_books.read()
	decrypted = f.decrypt(encrypted)

	file_books_new = open(file,'wb')
	file_books_new.write(decrypted)
	file_books_new.close()

def encrypt_file(file):
	f = key_fernet()
	
	file_books = open(file,'rb')
	original = file_books.read()
	encrypted = f.encrypt(original)
	
	file_books_new = open(file,'wb') 
	file_books_new.write(encrypted)
	file_books_new.close()