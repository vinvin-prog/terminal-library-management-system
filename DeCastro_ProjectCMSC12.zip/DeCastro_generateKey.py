'''
AMIEL VINCENT V. DE CASTRO
Y6L
'''

from cryptography.fernet import Fernet

key = Fernet.generate_key()

with open('key.key','wb') as file_key:
	file_key.write(key)