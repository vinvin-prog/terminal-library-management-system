'''
AMIEL VINCENT V. DE CASTRO
Y6L
'''

import DeCastro_books as books
import DeCastro_borrow as borrow
import DeCastro_logbook as logbook
import DeCastro_encryption as encryption

# DECRYPT FILE UPON OPENING
'''
encryption.decrypt_file("library.txt")
encryption.decrypt_file("borrow_list.txt")
encryption.decrypt_file("logbook.txt")
'''

def main_interface():

    # CREATES A LIBRARY DATA FILE TO STORE DATA
    file_library = "library.txt"

    # CREATES A BORROW LIST DATA FILE TO STORE DATA
    file_borrow_list = "borrow_list.txt"

    # CREATES A LOGBOOK DATA FILE TO STORE DATA
    file_logbook = "logbook.txt"

    while True:
        print("\n    Library Inventory and Logging System")
        print("\t[1] Go to Library")
        print("\t[2] Borrow Books")
        print("\t[3] Logbook")
        print("\t[4] Exit")
        choice = input("\nEnter option number: ").strip()

        if choice == "1":
            books.books_module(file_library, file_borrow_list)
        elif choice == "2":

            # IF LIBRARY IS CURRENTLY EMPTY, USER CANNOT PROCEED TO BORROW BOOKS
            library = books.load_books_from_file(file_library)
            
            if not library:
                print("\nCannot proceed to borrow books. There are currently no books in the library.")

            else:
                borrow.borrow_module(file_library, file_borrow_list, file_logbook)

        elif choice == "3":
            logbook.logbook_module(file_logbook, file_library)
        elif choice == "4":

            # ENCRYPT FILE AFTER USING
            '''
            encryption.encrypt_file("library.txt")
            encryption.encrypt_file("borrow_list.txt")
            encryption.encrypt_file("logbook.txt")
            '''
            print("\nThank you for using this system. Goodbye!")
            break
        else:
            print("\nInvalid user input. Please select a valid option.")

main_interface() # CALLS THE MAIN INTERFACE FUNCTION